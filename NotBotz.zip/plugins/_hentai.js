// OPPAI
global.hoppai = [
'https://telegra.ph/file/f34d76df4a2065af1a5ba.jpg',
'https://telegra.ph/file/05c1b22ee83bcd7723b4d.jpg',
'https://telegra.ph/file/1d886f66a44871205335f.jpg',
'https://telegra.ph/file/54d19a9094dc509370bf9.jpg',
'https://telegra.ph/file/e649475bcde78a9977ee5.jpg',
'https://telegra.ph/file/32ba20b6139b129c559c8.jpg',
'https://telegra.ph/file/948434cda49e4af5d9f11.jpg',
'https://telegra.ph/file/6f353c68533283fe79871.jpg',
'https://telegra.ph/file/de268ca9b01101acf2b8a.jpg',
'https://telegra.ph/file/fc6c5b2ae9a20c4256e7f.jpg',
'https://telegra.ph/file/efb70bb0988640f841742.jpg',
'https://telegra.ph/file/77d03fff530a2bcff3bf7.jpg',
'https://telegra.ph/file/6e4623464a659dd8d902b.jpg',
'https://telegra.ph/file/685aa39f0cb0f2c4fd85b.jpg',
'https://telegra.ph/file/10454b9ad693e1eefea58.jpg',
'https://telegra.ph/file/7de8ce5c290c3d8be0856.jpg',
'https://telegra.ph/file/8d7c4eadb7a4722747074.jpg',
'https://telegra.ph/file/ccc5f8eaac0f30919ef6c.jpg',
'https://telegra.ph/file/95f4b43439d7888f15ea5.jpg',
'https://telegra.ph/file/9c2a750db555bd2fad1f3.jpg',
'https://telegra.ph/file/efc5f7e637744fd6bfec2.jpg',
'https://telegra.ph/file/3a5231aade245665633bd.jpg',
'https://telegra.ph/file/2ecfc76feb26ec1eab99b.jpg',
'https://telegra.ph/file/dabb70983b4e833d98344.jpg',
'https://telegra.ph/file/75193a893e38fc580afe6.jpg',
'https://telegra.ph/file/217aa0f4ec76273808aa4.jpg',
'https://telegra.ph/file/8a35d3446b97ae22c7b23.jpg',
'https://telegra.ph/file/092df720701575a7ceaaa.jpg',
'https://telegra.ph/file/a65184a676cd648de34c3.jpg',
'https://telegra.ph/file/180e28807e78419d45537.jpg',
'https://telegra.ph/file/140eff27be983e0cd6781.jpg',
'https://telegra.ph/file/1581b791e16d0029e16b5.jpg',
'https://telegra.ph/file/6a4b36372b4f265bae3bc.jpg',
'https://telegra.ph/file/093caff422f194f00bc6c.jpg',
'https://telegra.ph/file/2294b7ab49eca8a8046b2.jpg',
'https://telegra.ph/file/869224d1c417e8b5c8ff1.jpg',
'https://telegra.ph/file/a78443f0ee887f46808d7.jpg',
'https://telegra.ph/file/1889878933264d16c58bf.jpg',
'https://telegra.ph/file/735aeb47d9c4aa87aaaf3.jpg',
'https://telegra.ph/file/fcf861516db09dda164e0.jpg',
'https://telegra.ph/file/355d96d7e06d109435f67.jpg'
]

   // WAIFU
global.hwaifu = [
'https://telegra.ph/file/a3bd959e8cf3131be2213.jpg',
'https://telegra.ph/file/f1558015373024dc03315.jpg',
'https://telegra.ph/file/7cc15f873161face95bd3.jpg',
'https://telegra.ph/file/0ed40d7fb5f8cbb938121.mp4'
]

   // YURI
global.hyuri = [
'https://telegra.ph/file/5d908f4a17515a15c6202.jpg',
'https://telegra.ph/file/e96c7b42a2d188018dc6c.png'
]

   // LOLI PIRANG
global.hLokun = [
'https://telegra.ph/file/8902f4fc550727a62e99f.jpg',
'https://telegra.ph/file/6a6a40e924c16a8f0de03.jpg',
'https://telegra.ph/file/b035d3038a0b124f1d846.jpg',
'https://telegra.ph/file/9d475f7852bf6f6193c80.jpg'
]

      // LOLI
global.hloli = [
'https://telegra.ph/file/872c360a7104d86752650.jpg',
'https://telegra.ph/file/f6bbb53620374257bfa51.jpg',
'https://telegra.ph/file/9b76375f3869440818d57.jpg',
'https://telegra.ph/file/a78443f0ee887f46808d7.jpg',
'https://telegra.ph/file/e13cf5bb69e77694e080d.png',
'https://telegra.ph/file/eff5bd9d5befd4c31d3b9.png'
]

     // NEKO
global.hneko = [
'https://telegra.ph/file/805a37b1e9a963e7d7ecf.jpg',
'https://telegra.ph/file/f9c4d97477b647cf57a2b.jpg',
'https://telegra.ph/file/b6905b77e6c7732592a13.jpg',
'https://telegra.ph/file/9f82c432d0ba4cfffda9a.png',
'https://telegra.ph/file/484083949d4bfd763b8cf.jpg',
'https://telegra.ph/file/56d4b993754e24c5436c1.jpg',
'https://telegra.ph/file/65a3371c6c7175a34fac0.jpg',
'https://telegra.ph/file/984706b5943cf876633cf.jpg'
]

      // BUNNY
global.hbunny = [
'https://telegra.ph/file/2b71a8d46d29351479fbc.jpg',
'https://telegra.ph/file/ae610571b62b5ab876e9c.jpg', 
'https://telegra.ph/file/cc8255d5b989eef587af2.jpg',
'https://telegra.ph/file/30d2e7375996abd9cfee3.jpg', 
'https://telegra.ph/file/78980c90c44a95a1d30fa.jpg', 
'https://telegra.ph/file/2ac5d8ccf23e73eaa5bfa.jpg',
'https://telegra.ph/file/e7459fffbdc9901bb03ae.jpg'
]

       // BEACH
global.hbeach = [
'https://telegra.ph/file/14ae0ba2da77d74e6b80c.jpg', 
'https://telegra.ph/file/b6905b77e6c7732592a13.jpg',
'https://telegra.ph/file/9da45a352eb4c40e5d641.jpg', 
'https://telegra.ph/file/59e78846ee365975ee6e3.jpg',
'https://telegra.ph/file/1bf7dee46b83eb4c41d7d.jpg',
'https://telegra.ph/file/0525a7929f819cb8278f3.jpg'
]

       // TRAP
global.htrap = [
'https://telegra.ph/file/4b2f8aed0dfbca0471b36.jpg',
'https://telegra.ph/file/65a3371c6c7175a34fac0.jpg',
'https://telegra.ph/file/f74a4729f77a64f4dbac4.jpg',
'https://telegra.ph/file/350a23734b20fe25d56f5.jpg',
'https://telegra.ph/file/d0daf3bca0753775efe6b.jpg'
]
 
       // FURY
global.hfury = [
'https://telegra.ph/file/f390a5d04555daab44132.jpg'
]
